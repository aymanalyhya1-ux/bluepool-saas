
import { useState } from "react";
import axios from "axios";

const api = axios.create({
  baseURL: "http://localhost:5000/api"
});

export default function App() {
  const [login, setLogin] = useState(false);
  const [visits, setVisits] = useState([]);

  const handleLogin = async () => {
    const res = await api.post("/auth/login", {
      phone: "0538351229",
      password: "123456"
    });

    localStorage.setItem("token", res.data.token);
    setLogin(true);

    const v = await api.get("/visits");
    setVisits(v.data);
  };

  if (!login) {
    return (
      <div style={{ padding: 20 }}>
        <h1>BluePool SaaS</h1>
        <button onClick={handleLogin}>تسجيل الدخول</button>
      </div>
    );
  }

  return (
    <div style={{ padding: 20 }}>
      <h2>الزيارات</h2>
      {visits.map(v => (
        <div key={v.id}>
          {v.pool} - {v.status}
        </div>
      ))}
    </div>
  );
}
